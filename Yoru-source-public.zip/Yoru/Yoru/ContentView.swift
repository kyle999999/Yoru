import SwiftUI

struct Anime: Identifiable, Codable {
    var id: String
    var title: String
    var subtitle: String
    var episodes: Int
    var watched: Int
    var saved: Bool
    var symbol: String
    var hue: Double
}

@Observable class Library {
    var shows: [Anime] { didSet { persist() } }
    init() {
        if let data = UserDefaults.standard.data(forKey: "yoru.library"), let saved = try? JSONDecoder().decode([Anime].self, from: data) { shows = saved }
        else { shows = [
            Anime(id: "frieren", title: "Frieren", subtitle: "Beyond Journey’s End", episodes: 28, watched: 6, saved: true, symbol: "sparkles", hue: 0.46),
            Anime(id: "bebop", title: "Cowboy Bebop", subtitle: "See you, space cowboy", episodes: 26, watched: 0, saved: false, symbol: "moon.stars.fill", hue: 0.07),
            Anime(id: "violet", title: "Violet Evergarden", subtitle: "Some words take a lifetime", episodes: 13, watched: 3, saved: true, symbol: "envelope.open.fill", hue: 0.69),
            Anime(id: "mob", title: "Mob Psycho 100", subtitle: "Find your own kind of extraordinary", episodes: 12, watched: 0, saved: false, symbol: "bolt.heart.fill", hue: 0.86),
            Anime(id: "champloo", title: "Samurai Champloo", subtitle: "A journey without a map", episodes: 26, watched: 0, saved: false, symbol: "sun.horizon.fill", hue: 0.02)
        ] }
    }
    func persist() { if let data = try? JSONEncoder().encode(shows) { UserDefaults.standard.set(data, forKey: "yoru.library") } }
    func save(_ id: String) { if let i = shows.firstIndex(where: { $0.id == id }) { shows[i].saved.toggle() } }
    func advance(_ id: String) { if let i = shows.firstIndex(where: { $0.id == id }), shows[i].watched < shows[i].episodes { shows[i].watched += 1; shows[i].saved = true } }
    func rewind(_ id: String) { if let i = shows.firstIndex(where: { $0.id == id }), shows[i].watched > 0 { shows[i].watched -= 1 } }
}

struct ContentView: View {
    @State private var library = Library()
    var body: some View {
        TabView {
            Tab("Tonight", systemImage: "moon.stars") { JournalScreen(library: library, mode: 0) }
            Tab("Discover", systemImage: "sparkle.magnifyingglass") { JournalScreen(library: library, mode: 1) }
            Tab("Library", systemImage: "square.stack") { JournalScreen(library: library, mode: 2) }
        }
        .tint(Color(red: 0.75, green: 0.64, blue: 1))
        .preferredColorScheme(.dark)
    }
}

struct JournalScreen: View {
    var library: Library
    var mode: Int
    @State private var query = ""
    @State private var selected: String?
    private let violet = Color(red: 0.75, green: 0.64, blue: 1)
    var filtered: [Anime] { library.shows.filter { (mode != 2 || $0.saved) && (query.isEmpty || $0.title.localizedCaseInsensitiveContains(query)) } }
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.035, green: 0.035, blue: 0.07).ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 28) {
                        header
                        if mode == 0 {
                            hero
                            HStack(spacing: 12) {
                                metric("EPISODES", "\(library.shows.reduce(0) { $0 + $1.watched })", "play.rectangle")
                                metric("YOUR COLLECTION", "\(library.shows.filter { $0.saved }.count)", "square.stack")
                            }
                            sectionTitle("Pick up the story", "YOUR NEXT EPISODE")
                            ForEach(library.shows.filter { $0.saved && $0.watched < $0.episodes }) { show in row(show, progress: true) }
                        } else {
                            HStack { Image(systemName: "magnifyingglass"); TextField("Find your next story", text: $query).autocorrectionDisabled() }.padding(16).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
                            if filtered.isEmpty {
                                ContentUnavailableView(mode == 2 ? "Your story starts here" : "No stories found", systemImage: "sparkles", description: Text(mode == 2 ? "Save a title in Discover to build your collection." : "Try another title."))
                            }
                            ForEach(filtered) { show in row(show, progress: mode == 2) }
                        }
                        Text("A LITTLE ESCAPE. A GREAT STORY.").font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(2.5).foregroundStyle(.white.opacity(0.3)).frame(maxWidth: .infinity).padding(.vertical, 24)
                    }.padding(.horizontal, 24).padding(.top, 16).padding(.bottom, 20)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(item: Binding(get: { selected.map { Selection(id: $0) } }, set: { selected = $0?.id })) { selection in
                if let show = library.shows.first(where: { $0.id == selection.id }) { detail(show) }
            }
        }
    }
    var header: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                HStack(spacing: 7) { Image(systemName: "moon.fill").foregroundStyle(violet); Text("yoru").font(.system(size: 24, weight: .semibold, design: .rounded)).tracking(-1) }
                Spacer()
                Text("夜  /  ANIME JOURNAL").font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(1.2).foregroundStyle(.white.opacity(0.4))
            }
            Text(mode == 0 ? "One more\nepisode?" : mode == 1 ? "Find your\nnext obsession." : "Stories you\nkeep close.")
                .font(.system(size: 43, weight: .semibold, design: .rounded)).tracking(-2).lineSpacing(-4)
            Text(mode == 0 ? "Leave the day behind. Your stories are waiting." : mode == 1 ? "A small collection of unforgettable worlds." : "Your pace. Your own little universe.").font(.system(size: 13)).foregroundStyle(.white.opacity(0.5))
        }
    }
    var hero: some View {
        Button { selected = library.shows[0].id } label: {
            ZStack(alignment: .bottomLeading) {
                artwork(library.shows[0]).frame(height: 270)
                LinearGradient(colors: [.clear, .black.opacity(0.9)], startPoint: .top, endPoint: .bottom)
                VStack(alignment: .leading, spacing: 10) {
                    Text("TONIGHT’S SPOTLIGHT").font(.system(size: 9, weight: .bold, design: .monospaced)).tracking(2).foregroundStyle(Color.mint)
                    Text("Some journeys\nnever really end.").font(.system(size: 29, weight: .medium, design: .serif)).foregroundStyle(.white)
                    HStack { Text("FRIEREN").font(.system(size: 11, weight: .bold)).tracking(2); Spacer(); Image(systemName: "arrow.up.right").padding(12).background(.ultraThinMaterial, in: Circle()) }.foregroundStyle(.white)
                }.padding(23)
            }.clipShape(RoundedRectangle(cornerRadius: 28)).overlay(RoundedRectangle(cornerRadius: 28).stroke(.white.opacity(0.13)))
        }.buttonStyle(.plain)
    }
    func metric(_ label: String, _ value: String, _ symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Image(systemName: symbol).foregroundStyle(violet); Spacer(); Text(value).font(.system(size: 23, weight: .medium, design: .rounded)) }
            Text(label).font(.system(size: 8, weight: .medium, design: .monospaced)).tracking(1.2).foregroundStyle(.white.opacity(0.4))
        }.padding(18).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(.white.opacity(0.07)))
    }
    func sectionTitle(_ title: String, _ eyebrow: String) -> some View {
        VStack(alignment: .leading, spacing: 8) { Text(eyebrow).font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(2).foregroundStyle(violet); Text(title).font(.system(size: 23, weight: .medium, design: .rounded)).tracking(-0.6) }
    }
    func artwork(_ show: Anime) -> some View {
        GeometryReader { geo in
            ZStack {
                LinearGradient(colors: [Color(hue: show.hue, saturation: 0.6, brightness: 0.45), Color(hue: show.hue + 0.08, saturation: 0.65, brightness: 0.12)], startPoint: .topLeading, endPoint: .bottomTrailing)
                Circle().fill(Color(hue: show.hue, saturation: 0.25, brightness: 1).opacity(0.25)).frame(width: geo.size.width * 0.65).blur(radius: 2).offset(x: geo.size.width * 0.2, y: -geo.size.height * 0.18)
                ForEach(0..<7) { i in
                    Capsule().fill(.white.opacity(0.035)).frame(width: 18, height: geo.size.height * 1.8).rotationEffect(.degrees(26)).offset(x: CGFloat(i - 3) * 53)
                }
                Image(systemName: show.symbol).font(.system(size: min(geo.size.width, geo.size.height) * 0.42, weight: .ultraLight)).foregroundStyle(.white.opacity(0.65)).offset(y: -geo.size.height * 0.12)
            }.frame(width: geo.size.width, height: geo.size.height).clipped()
        }
    }
    func row(_ show: Anime, progress: Bool) -> some View {
        HStack(spacing: 16) {
            Button { selected = show.id } label: { artwork(show).frame(width: 76, height: 103).clipShape(RoundedRectangle(cornerRadius: 15)) }.buttonStyle(.plain)
            VStack(alignment: .leading, spacing: 7) {
                Button { selected = show.id } label: { Text(show.title).font(.system(size: 17, weight: .semibold)).foregroundStyle(.white) }.buttonStyle(.plain)
                Text(show.subtitle).font(.system(size: 11)).foregroundStyle(.white.opacity(0.4)).lineLimit(2)
                if progress {
                    ProgressView(value: Double(show.watched), total: Double(show.episodes)).tint(violet).padding(.top, 5)
                    Text("\(show.watched) OF \(show.episodes) EPISODES").font(.system(size: 8, design: .monospaced)).tracking(1).foregroundStyle(.white.opacity(0.4))
                } else { Text("\(show.episodes) EPISODES  ·  SERIES").font(.system(size: 8, design: .monospaced)).tracking(1).foregroundStyle(violet).padding(.top, 5) }
            }
            Spacer(minLength: 0)
            Button { if progress { library.advance(show.id) } else { library.save(show.id) } } label: {
                Image(systemName: progress ? (show.watched == show.episodes ? "checkmark" : "plus") : (show.saved ? "bookmark.fill" : "bookmark")).font(.system(size: 16)).frame(width: 36, height: 36).background(.white.opacity(0.07), in: Circle())
            }.accessibilityLabel(progress ? "Log episode of \(show.title)" : "Toggle saved \(show.title)")
        }
    }
    func detail(_ show: Anime) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                artwork(show).frame(height: 260).clipShape(RoundedRectangle(cornerRadius: 28))
                Text(show.title).font(.system(size: 35, weight: .semibold, design: .rounded)).tracking(-1)
                Text(show.subtitle).foregroundStyle(.secondary)
                Text("Make room for another world. Keep track of every episode, one story at a time.").font(.system(size: 16)).foregroundStyle(.secondary)
                ProgressView(value: Double(show.watched), total: Double(show.episodes))
                Text("\(show.watched) / \(show.episodes) episodes watched").font(.system(.callout, design: .monospaced))
                Button { library.advance(show.id) } label: { Label(show.watched == show.episodes ? "Series completed" : "Log next episode", systemImage: "checkmark.circle.fill").frame(maxWidth: .infinity).padding(10) }.buttonStyle(.borderedProminent).disabled(show.watched == show.episodes)
                HStack {
                    Button("Undo episode") { library.rewind(show.id) }.disabled(show.watched == 0)
                    Spacer()
                    Button(show.saved ? "Remove from library" : "Save to library") { library.save(show.id) }
                }.font(.system(size: 13))
                Button("Done") { selected = nil }.frame(maxWidth: .infinity).padding()
            }.padding(24)
        }.presentationDragIndicator(.visible).preferredColorScheme(.dark)
    }
}
struct Selection: Identifiable { let id: String }
