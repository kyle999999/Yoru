# Dependency source snapshots

The revisions used for this build are recorded in ../DEPENDENCIES.json. Snapshots retain source code, licenses, headers, package/build metadata and test code. Texture’s website documentation and unrelated example applications/media are omitted from the archive; they are not part of the library build. The Xcode project resolves pinned dependencies from their original repositories normally. CWasm3 source for the linked v0.5.4 binary is included separately.
