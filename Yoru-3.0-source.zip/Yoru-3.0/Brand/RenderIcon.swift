import AppKit
import ImageIO
let context = CGContext(data: nil, width: 1024, height: 1024, bitsPerComponent: 8, bytesPerRow: 4096, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(cgContext: context, flipped: false)
let bounds = NSRect(x: 0, y: 0, width: 1024, height: 1024)
NSGradient(colors: [NSColor(srgbRed: 0.025, green: 0.025, blue: 0.065, alpha: 1), NSColor(srgbRed: 0.18, green: 0.10, blue: 0.31, alpha: 1)])!.draw(in: NSBezierPath(rect: bounds), angle: 45)
let outer = NSBezierPath(ovalIn: NSRect(x: 105, y: 355, width: 310, height: 310))
let moon = NSBezierPath(ovalIn: NSRect(x: 105, y: 355, width: 310, height: 310))
moon.append(NSBezierPath(ovalIn: NSRect(x: 205, y: 435, width: 280, height: 280)))
moon.windingRule = .evenOdd
NSGraphicsContext.saveGraphicsState(); outer.addClip()
NSColor(srgbRed: 0.79, green: 0.72, blue: 1, alpha: 1).setFill(); moon.fill()
NSGraphicsContext.restoreGraphicsState()
let regular = NSFont.systemFont(ofSize: 177, weight: .semibold)
let font = NSFont(descriptor: regular.fontDescriptor.withDesign(.rounded) ?? regular.fontDescriptor, size: 177)!
("yoru" as NSString).draw(at: NSPoint(x: 435, y: 409), withAttributes: [.font: font, .foregroundColor: NSColor(srgbRed: 0.96, green: 0.94, blue: 1, alpha: 1), .kern: -8])
let star = NSBezierPath();star.move(to: NSPoint(x: 397,y: 663));star.line(to:NSPoint(x:411,y:690));star.line(to:NSPoint(x:425,y:663));star.line(to:NSPoint(x:411,y:636));star.close()
NSColor(srgbRed:0.65,green:0.98,blue:0.85,alpha:1).setFill();star.fill()
NSGraphicsContext.restoreGraphicsState()
context.flush()
let target = URL(fileURLWithPath: CommandLine.arguments[1])
let destination = CGImageDestinationCreateWithURL(target as CFURL, "public.png" as CFString, 1, nil)!
CGImageDestinationAddImage(destination, context.makeImage()!, nil)
assert(CGImageDestinationFinalize(destination))
