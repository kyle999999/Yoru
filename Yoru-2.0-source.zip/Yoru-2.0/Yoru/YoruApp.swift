import SwiftUI

@main
struct YoruApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
