import SwiftUI

@Observable @MainActor final class Library {
    struct Entry: Codable { var anime: Anime; var watched: Int; var saved: Bool }
    private(set) var entries: [Int: Entry] = [:]
    private(set) var saveError: String?
    private let defaults: UserDefaults
    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: "yoru.library.v2"), let saved = try? JSONDecoder().decode([Int: Entry].self, from: data) {
            entries = saved
        } else { migrateLegacy() }
    }
    var saved: [Anime] { entries.values.filter(\.saved).map(\.anime).sorted { $0.displayTitle.localizedStandardCompare($1.displayTitle) == .orderedAscending } }
    var episodeCount: Int { entries.values.reduce(0) { $0 + $1.watched } }
    func isSaved(_ anime: Anime) -> Bool { entries[anime.id]?.saved ?? false }
    func watched(_ anime: Anime) -> Int { entries[anime.id]?.watched ?? 0 }
    func toggle(_ anime: Anime) {
        var entry = entries[anime.id] ?? Entry(anime: anime, watched: 0, saved: false)
        entry.saved.toggle(); entry.anime = anime; entries[anime.id] = entry; persist()
    }
    func log(_ anime: Anime, delta: Int = 1) {
        var entry = entries[anime.id] ?? Entry(anime: anime, watched: 0, saved: true)
        let next = max(0, entry.watched + delta)
        entry.watched = anime.episodes.map { min($0, next) } ?? next
        entry.saved = true; entry.anime = anime; entries[anime.id] = entry; persist()
    }
    func update(_ anime: Anime) {
        guard var entry = entries[anime.id] else { return }
        entry.anime = anime; entries[anime.id] = entry; persist()
    }
    private func persist() {
        do { defaults.set(try JSONEncoder().encode(entries), forKey: "yoru.library.v2"); saveError = nil }
        catch { saveError = "Your progress couldn’t be saved. Please try again." }
    }
    private func migrateLegacy() {
        struct Old: Decodable { var id: String; var title: String; var episodes: Int; var watched: Int; var saved: Bool }
        let ids = ["frieren": 52991, "bebop": 1, "violet": 33352, "mob": 32182, "champloo": 205]
        guard let data = defaults.data(forKey: "yoru.library"), let old = try? JSONDecoder().decode([Old].self, from: data) else { return }
        for show in old {
            guard let id = ids[show.id], show.saved || show.watched > 0 else { continue }
            entries[id] = Entry(anime: Anime(malId: id, title: show.title, episodes: show.episodes), watched: show.watched, saved: show.saved)
        }
        persist()
    }
}

@Observable @MainActor final class CatalogStore {
    var items: [Anime] = []
    var isLoading = false
    var error: String?
    var isStale = false
    var fetchedAt: Date?
    var hasMore = false
    var pageNumber = 0
    private var generation = UUID()
    private var path = ""
    private var parameters: [String: String] = [:]

    func load(path: String, parameters: [String: String] = [:], allPages: Bool = false, refresh: Bool = false) async {
        let requestID = UUID(); generation = requestID
        self.path = path; self.parameters = parameters
        isLoading = true; error = nil; isStale = false
        items = []; hasMore = false; pageNumber = 0; fetchedAt = nil
        defer { if generation == requestID { isLoading = false } }
        repeat {
            do {
                let result = try await AnimeAPI.shared.page(path: path, parameters: parameters, page: pageNumber + 1, refresh: refresh)
                try Task.checkCancellation()
                guard generation == requestID else { return }
                append(result); pageNumber += 1
            } catch is CancellationError { return }
            catch {
                guard generation == requestID else { return }
                self.error = error.localizedDescription; return
            }
        } while allPages && hasMore
    }
    func loadMore() async {
        guard hasMore, !isLoading else { return }
        let requestID = generation; isLoading = true; error = nil
        defer { if generation == requestID { isLoading = false } }
        do {
            let result = try await AnimeAPI.shared.page(path: path, parameters: parameters, page: pageNumber + 1)
            try Task.checkCancellation()
            guard generation == requestID else { return }
            append(result); pageNumber += 1
        } catch is CancellationError {} catch { if generation == requestID { self.error = error.localizedDescription } }
    }
    private func append(_ result: APIResponse<AnimePage>) {
        var seen = Set(items.map(\.id))
        items.append(contentsOf: result.value.data.filter { seen.insert($0.id).inserted })
        hasMore = result.value.pagination.hasNextPage
        isStale = isStale || result.isStale
        fetchedAt = min(fetchedAt ?? result.fetchedAt, result.fetchedAt)
    }
}
